﻿using System;

namespace GoldenDragonHotPotHouseRestaurantSystem
{
    class Payment
    {
        private int method;
        private int table_id;
        private string transaction_datetime;
        private decimal tax;
        private decimal subtotal;
        private decimal gratuity;
        private decimal total_payment_amount;
        private int transactionNumber;
        // Member variable Get and set properties logic here.
        protected int TransactionNumber { get; set; }
        protected decimal Total_payment_amount { get; }
        private void getTotalPaymentAmount(int order_id)
        {
            // Calculate the total payment amount logic here.
        }
        private void processPaymentType(int method)
        {
            // Send total payment amount to inherited class logic here.
        }
    }
    class Cash : Payment
    {
        private int processCash(decimal total_payment_amount, int transactionNumber)
        {
            // Process cash payment here.
            return transactionNumber;
        }
    }
    class CreditC : Payment
    {
        private int processCreditCard(decimal total_payment_amount, int transactionNumber)
        {
            // Process credit card payment here.
            return transactionNumber;
        }
    }
    class DebitC : Payment
    {
        private int processDebitCard(decimal total_payment_amount, int transactionNumber)
        {
            // Process debit card payment here.
            return transactionNumber;
        }
    }
}

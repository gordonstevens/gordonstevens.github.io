﻿using System;
namespace GoldenDragonHotPotHouseRestaurantSystem
{
    class TableOrder
    {
        private int order_id;
        private int table_id;
        private int membership_id;
        private int adult_number;
        private int children_number;
        private decimal total_amount;
        private int table_section;
        // Get and Set properties logic here
        public int Order_id { get; }
        public int Table_id { get; }
        public int Membership_id { get; set; }
        public int Adult_number { get; }
        public int Children_number { get; }
        public decimal Total_amount { get; set; }
        public int Table_section { get; set; }
        // Methods
        private void membershipCheck(int membership_id)
        {
            // Check for membership information logic here.
        }
        private void processTotal(int order_id)
        {
            // Process total amount and calls to payment class logic here.
        }
        private void processPayment(int order_id)
        {
            // Process payment and calls to payment class logic here.
        }
        private void sentToKitchen(int order_id)
        {
            // Put order onto the kitchen displays logic here.
        }
        private void feedbackSubmit(int feedback_rating, string feedback_desc)
        {
            // Submit feedback logic here.
        }
        private void feedbackRetraction(int feedback_id)
        {
            // Retract feedback logic here.
        }
        private void feedbackEdit(int feedback_id)
        {
            // Edit feedback logic here.
        }
    }
    class Order : TableOrder
    {
        private int status;
        // Methods
        private void viewOrder(int order_id)
        {
            // View order logic here.
        }
        private void addOrderItem(int order_id, int item_id)
        {
            // View order logic here.
        }
    }
    class OrderItem : Order
    {
        private int orderitem_id;
        private int item_id;
        private int quantity;
        // Get and Set properties logic here.
        public int Orderitem_id { get; set; }
        public int Item_id { get; set; }
        public int Quantity { get; set; }
        // Methods
        private void viewOrderItem()
        {
            // View order item logic here.
        }
        private void createOrderItem()
        {
            // Create order item logic here.
        }
    }
    class Item : OrderItem
    {
        private int item_id;
        private decimal price;
        private int category_id;
        private string description;
        // Get and Set properties logic here.
        public decimal Price { get; set; }
        public string Description { get; }
        // Methods
        private decimal getPrice(int item_id)
        {
            // Get item price logic here.
            return item_price;
        }
        private string getDesc(int item_id)
        {
            // Get item description logic here.
            return item_description;
        }
    }
    class Category : Item
    {
        private int category_id;
        private string category_name;
        // Get and Set properties
        public int Category_id { get; }
        public string Category_name { get; }
        // Method
        private void addCategory()
        {
            // Add a category logic here.
        }
        private void displayCategories()
        {
            // Display categories logic here.
        }
    }
}
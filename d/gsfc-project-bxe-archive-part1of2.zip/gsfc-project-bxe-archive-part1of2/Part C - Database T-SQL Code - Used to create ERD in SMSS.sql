/* Written in Transact-SQL for MS SQL Server/Azure - Using default dbo schema */
USE GoldenHotPot;
GO
CREATE TABLE [dbo].[Employee] (
	[employee_id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[firstName] nvarchar(50) NOT NULL,
	[lastName] nvarchar(50) NOT NULL,
	[hire_date] date NOT NULL,
	[manager_id] int NOT NULL,
	[table_section] int NOT NULL,
	[station] int NOT NULL
	);
CREATE TABLE [dbo].[TableOrder] (
	[table_id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[membership_id] int NOT NULL,
	[adult_number] int NOT NULL,
	[children_number] int NOT NULL,
	[total_amount] money NOT NULL,
	[employee_id] int NOT NULL,
	[table_section] int NOT NULL
	);
CREATE TABLE [dbo].[TOrder] (
	[order_id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[table_id] int NOT NULL,
	[status] int NOT NULL
	);
CREATE TABLE [dbo].[Membership] (
	[membership_id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[firstName] nvarchar(50) NOT NULL,
	[lastName] nvarchar(50) NOT NULL,
	[email] nvarchar(255) NOT NULL,
	[phoneNumber] nvarchar(35) NOT NULL,
	[address] nvarchar(255) NOT NULL,
	[point] int NOT NULL,
	[signUpDate] date NOT NULL
	);
CREATE TABLE [dbo].[OrderItem] (
	[orderItem_id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[order_id] int NOT NULL,
	[item_id] int NOT NULL,
	[quantity] int NOT NULL,
	[status] int NOT NULL
	);
CREATE TABLE [dbo].[Item] (
	[item_id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[price] money NOT NULL,
	[category_id] int NOT NULL,
	[description] nvarchar(255) NOT NULL
	);
CREATE TABLE [dbo].[Category] (
	[category_id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[item_id] int NOT NULL,
	[category_name] nvarchar(50) NOT NULL
	);
CREATE TABLE [dbo].[Payment] (
	[payment_id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[method] int NOT NULL,
	[table_id] int NOT NULL,
	[transaction_datetime] date NOT NULL,
	[tax] money NOT NULL,
	[subtotal] money NOT NULL,
	[total_payment_amount] money NOT NULL,
	[gratuity] money NOT NULL,
	[transaction_number] int NOT NULL
	);
/* Add Foreign Key Constraints */
ALTER TABLE [dbo].[TableOrder] ADD CONSTRAINT FK_membership_id FOREIGN KEY (membership_id) REFERENCES dbo.Membership (membership_id);
ALTER TABLE [dbo].[TableOrder] ADD CONSTRAINT FK_employee_id FOREIGN KEY (employee_id) REFERENCES dbo.Employee (employee_id);
ALTER TABLE [dbo].[TOrder] ADD CONSTRAINT FK_table_id FOREIGN KEY (table_id) REFERENCES dbo.TableOrder (table_id);
ALTER TABLE [dbo].[Payment] ADD CONSTRAINT FK_table_payment_id FOREIGN KEY (table_id) REFERENCES dbo.TableOrder (table_id);
ALTER TABLE [dbo].[Item] ADD CONSTRAINT FK_item_id FOREIGN KEY (item_id) REFERENCES dbo.OrderItem (item_id);
ALTER TABLE [dbo].[OrderItem] ADD CONSTRAINT FK_order_id FOREIGN KEY (order_id) REFERENCES dbo.TOrder (order_id);
ALTER TABLE [dbo].[OrderItem] ADD CONSTRAINT FK_orderitem_id FOREIGN KEY (item_id) REFERENCES dbo.Item (item_id);
ALTER TABLE [dbo].[Category] ADD CONSTRAINT FK_item_category_id FOREIGN KEY (item_id) REFERENCES dbo.Item (item_id);
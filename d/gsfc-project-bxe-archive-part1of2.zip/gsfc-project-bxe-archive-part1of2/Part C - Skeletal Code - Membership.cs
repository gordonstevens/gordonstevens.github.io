﻿using System;

namespace GoldenDragonHotPotHouseRestaurantSystem
{
    class Membership
    {
        private int membership_id;
        private string firstName;
        private string lastName;
        private string email;
        private decimal phoneNumber;
        private string address;
        private int point;
        private string signUpDate;
        // Get and set properties
        public int Membership_id { get; }
        public Membership(string firstName, string lastName, string email, decimal phoneNumber, string address, int point)
        {
            // Class constructor logic here.
        }
        private void membershipAdd(string firstName, string lastName, string email, decimal phoneNumber, string address, int point)
        {
            // Add a membership logic here.
        }
        private void membershipDel(int membership_id, string membership_deletion_reason)
        {
            // Add a membership logic here.
        }
        private void membershipEdit(int membership_id)
        {
            // Edit a membership logic here.
        }
        private void membershipView(int membership_id)
        {
            // View a membership logic here.
        }
    }
}
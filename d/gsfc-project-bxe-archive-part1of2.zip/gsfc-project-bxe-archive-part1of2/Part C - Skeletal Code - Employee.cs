﻿using System;
namespace GoldenDragonHotPotHouseRestaurantSystem
{
    class Employee
    {
        private int employee_id;
        private string firstName;
        private string lastName;
        private string password;
        private DateTime hire_date;
        private int manager_id;
        public Employee()
        {
            // Class constuctor logic here.
        }
        public void empSignIn(string firstName, string lastName, string password)
        {
            // Login logic here.
        }
        public void empSignOut()
        {
            // Logout logic here.
        }
        public bool empIsLoggedIn()
        {
            // Authentication check logic here.
            return true;
        }
        public int empType()
        {
            // Return employee role logic here.
            return employeeRoleType;
        }
    }
    class Waiter : Employee
    {
        private int table_section;
        private void orderAddItem(int order_id, int item_id)
        {
            // Add item to order logic here.
        }
        private void orderEditItem(int order_id, int item_id)
        {
            // Edit item in order logic here.
        }
        private void orderView(int order_id)
        {
            // View order logic here.
        }
        private void receiptPrint(int order_id, int receipt_type)
        {
            // Print receipt logic here.
        }
    }
    class Cook : Employee
    {
        private int station;
        private void orderView(int order_id)
        {
            // View order on kitchen display logic here.
        }
        private void orderPrep(int order_id)
        {
            // Prep order on kitchen display logic here.
        }
        private void orderComplete(int order_id)
        {
            // Complete the order on kitchen display logic here.
        }
    }
    class Manager : Employee
    {
        private void empAdd(string firstName, string lastName, string password)
        {
            // Add an employee logic here.
        }
        private void empDrop(int employee_id, int employee_drop_code, string drop_remarks)
        {
            // Drop/delete an employee logic here.
        }
        private void empEdit(int employee_id)
        {
            // Edit an employee logic here.
        }
        private void orderAddItem(int order_id)
        {
            // Manager: Add an order item logic here.
        }
        private void orderEditItem(int order_id)
        {
            // Manager: Edit an order item logic here.
        }
        private void orderView(int order_id)
        {
            // Manager: View an order logic here.
        }
        private void orderVoid(int order_id, string order_void_reason)
        {
            // Manager: Void an order logic here.
        }
        private void membershipAdd(string firstName, string lastName, string email, decimal phoneNumber, int point)
        {
            // Manager: Manually add a membership logic here.
        }
        private void membershipDelete(int membership_id)
        {
            // Manager: Manually delete a membership logic here.
        }
        private void membershipEdit(int membership_id)
        {
            // Manager: Manually edit membership details logic here.
        }
        private void membershipView(int membership_id)
        {
            // Manager: View membership details logic here.
        }
        private void menuAddItem(string menu_item_name, string menu_item_desc)
        {
            // Add an item to the restaurant menu logic here.
        }
        private void menuEditItem(int menu_item_id)
        {
            // Edit an item on the restaurant menu logic here.
        }
        private void menuDelItem(int menu_item_id)
        {
            // Delete an item on the restaurant menu logic here.
        }
        private void reportDailySales(int report_detail_style)
        {
            // Display daily sales report logic here.
        }
        private void reportMonthlySales(int report_detail_style)
        {
            // Display monthly sales report logic here.
        }
        private void reportYearlySales(int report_detail_style)
        {
            // Display year-to-date sales report logic here.
        }
    }
}
﻿using System;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
public partial class recipes : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Orignal, Changed to show only loggedin user's recipes
            // --- Return all recipes, and show everying but the Recipe Id (redId)
            string allRecipesSearchQuery = "SELECT r.recName, r.recDescription, category.categoryName, cuisine.cuisineName, r.recDirections, r.recUserId, r.recPrepTime, r.recCookTime, r.recPortion, r.recPrivate FROM comp229recipe r INNER JOIN comp229category category ON r.recCategoryId = category.CategoryId INNER JOIN comp229cuisine cuisine ON r.recCuisineId = cuisine.CuisineId ORDER BY r.recId";
            // Return only logged-in active user's public and private recipes, and show everying but the Recipe Id (redId)
            string userRecipesSearchQuery = "SELECT r.recName, r.recDescription, category.categoryName, cuisine.cuisineName, r.recDirections, r.recUserId, r.recPrepTime, r.recCookTime, r.recPortion, r.recPrivate FROM comp229recipe r INNER JOIN comp229category category ON r.recCategoryId = category.CategoryId INNER JOIN comp229cuisine cuisine ON r.recCuisineId = cuisine.CuisineId WHERE  r.recUserId = '" + System.Web.HttpContext.Current.User.Identity.Name + "' ORDER BY r.recId";
            // For the connection, use the connection string from web.config
            SqlConnection connection = new SqlConnection(WebConfigurationManager.ConnectionStrings["RecipeLocalDatabaseR2ConnectionString"].ConnectionString);
            // Use a SqlDataAdapter
            SqlDataAdapter adapter = new SqlDataAdapter(userRecipesSearchQuery, connection);
            // Use a DataSet
            DataSet recDataSet = new DataSet();
            // Fill the Adapter with the DataSet
            adapter.Fill(recDataSet);
            try
            {
                // Set DataSource on the GridView
                gvRecipeList.DataSource = recDataSet;
                // Bind DataSet to GridView
                gvRecipeList.DataBind();
            }
            catch (Exception ex)
            {
                lblErrorMsg.Text = "Error: " + ex.Message;
            }
        }
    }
    protected void gvRecipeList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        // Change Header Text REF: http://stackoverflow.com/questions/13013241/change-header-text-of-columns-in-a-gridview
        // Get header row Text REF: http://stackoverflow.com/questions/2091202/get-header-text-of-gridview-cell
        // Find header row controls REF: http://stackoverflow.com/questions/7632033/how-can-find-header-controls-in-gridview
        /*string[] headerText = new string[10] { "Recipe Name", "Description", "Directions", "Submitted By", "Category", "Cuisine", "Prep Time", "Cook Time", "Portions", "Private" };*/
        string[] headerText = new string[10] { "Recipe", "Description", "Category", "Cuisine", "Directions", "User Id", "Prep Time", "Cook Time", "Portion", "Private" };
        if (e.Row.RowType == DataControlRowType.Header)
            for (int ht = 0; ht <= headerText.Length - 1; ht++)
                e.Row.Cells[ht].Text = "<center>" + headerText[ht] + "</center>";
        // Datarow REF: https://msdn.microsoft.com/en-us/library/system.web.ui.webcontrols.gridviewroweventargs.row(v=vs.110).aspx
        else if (e.Row.RowType == DataControlRowType.DataRow)
            for (int rt = 0; rt <= e.Row.Cells.Count - 1; rt++)
                e.Row.Cells[rt].Text = "<center>" + e.Row.Cells[rt].Text + "</center>";
    }
}
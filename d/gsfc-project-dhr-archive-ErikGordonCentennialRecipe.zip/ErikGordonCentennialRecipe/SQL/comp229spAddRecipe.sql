CREATE PROCEDURE [dbo].[comp229spAddRecipe]
	@recName NVARCHAR(50),
	@recDescription NVARCHAR(256),
	@recDirections NVARCHAR(3500),
	@recUserId NVARCHAR(50),
	@recCategoryId INT,
	@recCuisineId INT,
	@recPrepTime INT,
	@recCookTime INT,
	@recPortion INT,
	@recPrivate NVARCHAR(3)
AS
INSERT INTO [dbo].[comp229recipe] (
	[recName],        
	[recDescription],
	[recDirections],        
	[recUserId],    
	[recCategoryId],    
	[recCuisineId],
	[recPrepTime],     
	[recCookTime],     
	[recPortion],           
	[recPrivate])
	VALUES (
	@recName,
	@recDescription,
	@recDirections,
	@recUserId,
	@recCategoryId,
	@recCuisineId,
	@recPrepTime,
	@recCookTime,
	@recPortion,
	@recPrivate)
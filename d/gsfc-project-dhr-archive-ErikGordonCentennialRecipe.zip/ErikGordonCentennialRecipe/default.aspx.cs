﻿using System;
public partial class home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // If the HomePageCounter doesn't exists, instantiate it. I use a more unique name so it isn't confused with other
        if (Application["RecipeHomePageCounter300864022"] == null)
            Application["RecipeHomePageCounter300864022"] = 1;
        else
        {
            Application.Lock(); // Allow only one client to modify the counter at once, use locking
            Application["RecipeHomePageCounter300864022"] = (int)Application["RecipeHomePageCounter300864022"] + 1;
            Application.UnLock();
        }
        // Update the label
        lblHomePageCounter.Text = Convert.ToString(Application["RecipeHomePageCounter300864022"]);
    }
}
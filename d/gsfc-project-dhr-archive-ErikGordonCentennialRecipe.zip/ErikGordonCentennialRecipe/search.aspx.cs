﻿using System;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
public partial class search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string searchQuery = "SELECT r.recName, r.recDescription, category.categoryName, cuisine.cuisineName, r.recDirections, r.recUserId, r.recPrepTime, r.recCookTime, r.recPortion, r.recPrivate FROM comp229recipe r INNER JOIN comp229category category ON r.recCategoryId = category.CategoryId INNER JOIN comp229cuisine cuisine ON r.recCuisineId = cuisine.CuisineId";
        // IF there is a search string, then search for it ELSE show all
        if (txtSearchQuery.Text != "")
        {
            // WHERE added to have selected searches. Adds to my base SELECT statement
            switch (ddlSearchType.SelectedValue)
            {
                case "Recipe Name":
                    searchQuery += " WHERE r.recName LIKE '%" + txtSearchQuery.Text + "%'";
                    break;
                case "Description":
                    searchQuery += " WHERE r.recDescription LIKE '%" + txtSearchQuery.Text + "%'";
                    break;
                case "Directions":
                    searchQuery += " WHERE r.recDirections LIKE '%" + txtSearchQuery.Text + "%'";
                    break;
                case "Submitted By":
                    searchQuery += " WHERE r.recUserId LIKE '%" + txtSearchQuery.Text + "%'";
                    break;
                case "Category":
                    searchQuery += " WHERE category.CategoryName LIKE '%" + txtSearchQuery.Text + "%'";
                    break;
                case "Cuisine":
                    searchQuery += " WHERE cuisine.CuisineName LIKE '%" + txtSearchQuery.Text + "%'";
                    break;
                case "Cook Time":
                    searchQuery += " WHERE r.recCookTime LIKE '%" + txtSearchQuery.Text + "%'";
                    break;
                case "Portion":
                    searchQuery += " WHERE r.recPortion LIKE '%" + txtSearchQuery.Text + "%'";
                    break;
                case "Show All":
                default:
                    break;
            }
            // If Private checkbox is selected, only show private recipes ELSE show not private only - Get logged in UserName REF: http://stackoverflow.com/questions/5417125/how-to-get-current-user-whos-accessing-asp-net-app
            if (chkSearchPrivate.Checked)
                searchQuery += " AND r.recPrivate = 'Yes' AND r.recUserId = '" + System.Web.HttpContext.Current.User.Identity.Name + "'";
            else
                searchQuery += " AND r.recPrivate = 'No'";
        }
        else
        {
            // If Private checkbox is selected, only show private recipes ELSE show not private only
            if (chkSearchPrivate.Checked)
                searchQuery = "SELECT r.recName, r.recDescription, category.categoryName, cuisine.cuisineName, r.recDirections, r.recUserId, r.recPrepTime, r.recCookTime, r.recPortion, r.recPrivate FROM comp229recipe r INNER JOIN comp229category category ON r.recCategoryId = category.CategoryId INNER JOIN comp229cuisine cuisine ON r.recCuisineId = cuisine.CuisineId WHERE r.recPrivate = 'Yes' AND r.recUserId = '" + System.Web.HttpContext.Current.User.Identity.Name + "'";
            else
                searchQuery = "SELECT r.recName, r.recDescription, category.categoryName, cuisine.cuisineName, r.recDirections, r.recUserId, r.recPrepTime, r.recCookTime, r.recPortion, r.recPrivate FROM comp229recipe r INNER JOIN comp229category category ON r.recCategoryId = category.CategoryId INNER JOIN comp229cuisine cuisine ON r.recCuisineId = cuisine.CuisineId WHERE r.recPrivate = 'No'";
        }
        // No matter what, order the query by recipe Id
        searchQuery += " ORDER BY r.recId DESC";
        // SQL Connection
        SqlConnection connection = new SqlConnection(WebConfigurationManager.ConnectionStrings["RecipeLocalDatabaseR2ConnectionString"].ConnectionString);
        // SQL Adapter
        SqlDataAdapter adapter = new SqlDataAdapter(searchQuery, connection);
        // SQL DataSet
        DataSet recDataSet = new DataSet();
        try
        {
            // Fill adapter with dataset
            adapter.Fill(recDataSet);
            gvSearch.DataSource = recDataSet;
            // Bind DataSet to GridView
            gvSearch.DataBind();
        }
        catch (SqlException ex)
        {
            lblErrorMsg.Text = "Error: " + ex.Message;
        }
    }
    protected void gvSearch_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        // Change Header Text REF: http://stackoverflow.com/questions/13013241/change-header-text-of-columns-in-a-gridview
        // Get header row Text REF: http://stackoverflow.com/questions/2091202/get-header-text-of-gridview-cell
        // Find header row controls REF: http://stackoverflow.com/questions/7632033/how-can-find-header-controls-in-gridview
        /*string[] headerText = new string[10] { "Recipe Name", "Description", "Directions", "Submitted By", "Category", "Cuisine", "Prep Time", "Cook Time", "Portions", "Private" };*/
        string[] headerText = new string[10] { "Recipe", "Description", "Category", "Cuisine", "Directions", "User Id", "Prep Time", "Cook Time", "Portion", "Private" };
        if (e.Row.RowType == DataControlRowType.Header)
            for (int ht = 0; ht <= headerText.Length - 1; ht++)
                e.Row.Cells[ht].Text = "<center>" + headerText[ht] + "</center>";
        // Datarow REF: https://msdn.microsoft.com/en-us/library/system.web.ui.webcontrols.gridviewroweventargs.row(v=vs.110).aspx
        else if (e.Row.RowType == DataControlRowType.DataRow)
            for (int rt = 0; rt <= e.Row.Cells.Count - 1; rt++)
                e.Row.Cells[rt].Text = "<center>" + e.Row.Cells[rt].Text + "</center>";
    }
}
﻿using System;
public partial class register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void CreateUserWizard_CreatedUser(object sender, EventArgs e)
    {
        // Add new registration to Role "User"
        System.Web.Security.Roles.AddUserToRole(wizCreateUser.UserName, "User");
    }
}
﻿using System;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
public partial class add : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        populateddl_ddlCategory();
        populateddl_ddlCuisine();
    }
    private void populateddl_ddlCategory()
    {
        // Create connection object
        SqlConnection connection = new SqlConnection(WebConfigurationManager.ConnectionStrings["RecipeLocalDatabaseR2ConnectionString"].ConnectionString);

        // Create SQL query
        string categoryQuery = "SELECT * FROM [dbo].[comp229category]";

        // Create SQL command
        SqlCommand categoryCommand = new SqlCommand(categoryQuery, connection);

        // Open connection
        categoryCommand.Connection.Open();

        // Execute query and store results in reader
        SqlDataReader categoryReader = categoryCommand.ExecuteReader();

        // Add reader to drop down list
        ddlCategoryName.DataSource = categoryReader;
        ddlCategoryName.DataTextField = "categoryName";
        ddlCategoryName.DataValueField = "categoryId";

        // Bind data to drop down list
        ddlCategoryName.DataBind();

        // Close Reader and Connection
        categoryReader.Close();
        categoryCommand.Connection.Close();
    }
    private void populateddl_ddlCuisine()
    {
        // Create connection object
        SqlConnection connection = new SqlConnection(WebConfigurationManager.ConnectionStrings["RecipeLocalDatabaseR2ConnectionString"].ConnectionString);

        // Create SQL query
        string cuisineQuery = "SELECT * FROM [dbo].[comp229cuisine]";

        // Create SQL command
        SqlCommand cuisineCommand = new SqlCommand(cuisineQuery, connection);

        // Open connection
        cuisineCommand.Connection.Open();

        // Execute query and store results in reader
        SqlDataReader cuisineReader = cuisineCommand.ExecuteReader();

        // Add reader to drop down list
        ddlCuisineName.DataSource = cuisineReader;
        ddlCuisineName.DataTextField = "cuisineName";
        ddlCuisineName.DataValueField = "cuisineId";

        // Bind data to drop down list
        ddlCuisineName.DataBind();

        // Close Reader and Connection
        cuisineReader.Close();
        cuisineCommand.Connection.Close();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated) {
            // Create connection object
            SqlConnection connection = new SqlConnection(WebConfigurationManager.ConnectionStrings["RecipeLocalDatabaseR2ConnectionString"].ConnectionString);
            // Open connection
            connection.Open();
            // create command object from SqlCommand (query, connection)
            SqlCommand command = new SqlCommand("comp229spAddRecipe", connection);
            // Tell command object to use Stored Procedure
            command.CommandType = CommandType.StoredProcedure;
            // Make param Sql Parameter object
            // SqlParameter REF: https://msdn.microsoft.com/en-us/library/system.data.sqlclient.sqlparameter.sourceversion(v=vs.110).aspx
            // SqlParameter Properties REF: https://msdn.microsoft.com/en-us/library/system.data.sqlclient.sqlcommand.parameters(v=vs.110).aspx
            // Add parameters REF: https://msdn.microsoft.com/en-us/library/40959t6x(v=vs.110).aspx
            SqlParameter parameter;
            // Recipe Name
            parameter = new SqlParameter("@recName", SqlDbType.NVarChar, 50);
            parameter.Value = txtRecipeName.Text;
            command.Parameters.Add(parameter);
            // Recipe Description
            parameter = new SqlParameter("@recDescription", SqlDbType.NVarChar, 256);
            parameter.Value = txtRecipeDescription.Text;
            command.Parameters.Add(parameter);
            // Recipe Directions
            parameter = new SqlParameter("@recDirections", SqlDbType.NVarChar, 3500);
            parameter.Value = txtRecipeDirections.Text;
            command.Parameters.Add(parameter);
            // Recipe User Id - Get logged in UserName REF: http://stackoverflow.com/questions/5417125/how-to-get-current-user-whos-accessing-asp-net-app
            parameter = new SqlParameter("@recUserId", SqlDbType.NVarChar, 50);
            parameter.Value = System.Web.HttpContext.Current.User.Identity.Name;
            command.Parameters.Add(parameter);
            // Recipe Category Name
            parameter = new SqlParameter("@recCategoryId", SqlDbType.Int);
            parameter.Value = ddlCategoryName.Text;
            command.Parameters.Add(parameter);
            // Recipe Cuisine Name
            parameter = new SqlParameter("@recCuisineId", SqlDbType.Int);
            parameter.Value = ddlCuisineName.Text;
            command.Parameters.Add(parameter);
            // Recipe Prep Time
            parameter = new SqlParameter("@recPrepTime", SqlDbType.Int);
            parameter.Value = txtPrepTime.Text;
            command.Parameters.Add(parameter);
            // Recipe Cooking Time
            parameter = new SqlParameter("@recCookTime", SqlDbType.Int);
            parameter.Value = txtCookTime.Text;
            command.Parameters.Add(parameter);
            // Recipe Portions
            parameter = new SqlParameter("@recPortion", SqlDbType.Int);
            parameter.Value = txtPortion.Text;
            command.Parameters.Add(parameter);
            // Recipe Privacy
            parameter = new SqlParameter("@recPrivate", SqlDbType.NVarChar, 3);
            parameter.Value = (chkRecipePrivacy.Checked) ? "Yes" : "No";
            command.Parameters.Add(parameter);
            try
            {
                command.ExecuteNonQuery();
                lblResultant.Text = "Recipe added successfully!";
            }
            catch (SqlException ex)
            {
                lblResultant.Text = "Recipe NOT added! Error: " + ex.Message;
            }
            finally
            {
                // Always close the connection to the database
                command.Connection.Close();
            }
        }
        else
        {
            Response.Redirect("login.aspx");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.Security;
public partial class usermanagement : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            BindGrid();
    }
    protected void BindGrid()
    {
        SqlConnection connection = new SqlConnection(WebConfigurationManager.ConnectionStrings["RecipeLocalDatabaseR2ConnectionString"].ConnectionString);
        string query = "Select Usr.UserName,RL.RoleName from dbo.aspnet_Users Usr inner join dbo.aspnet_UsersInRoles RLU  on  Usr.UserId=RLU.UserId inner join dbo.aspnet_Roles RL on Rl.RoleId=RLU.RoleId";
        SqlCommand command = new SqlCommand(query, connection);
        connection.Open();
        gvUserManagement.DataSource = command.ExecuteReader();
        gvUserManagement.DataBind();
        connection.Close();
    }
    protected void btnCreateRole_Click(object sender, EventArgs e)
    {
        if (!Roles.RoleExists(txtCreateRole.Text))
            Roles.CreateRole(txtCreateRole.Text);
    }
    protected void btnAddUserToRole_Click(object sender, EventArgs e)
    {
        if (Roles.RoleExists(txtRole.Text))
        {
            string[] userRoles = Roles.GetRolesForUser(txtUserName.Text);
            Roles.RemoveUserFromRoles(txtUserName.Text, userRoles);
            Roles.AddUserToRole(txtUserName.Text, txtRole.Text);
            BindGrid();
        }
    }
}
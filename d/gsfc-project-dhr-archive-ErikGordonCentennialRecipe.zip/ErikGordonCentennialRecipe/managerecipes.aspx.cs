﻿using System;
using System.Configuration;
using System.Data.SqlClient;
public partial class managerecipes : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void btnCreateCategory_Click(object sender, EventArgs e)
    {
        if ((txtCreateCategory.Text.Length <= 25) || (txtCreateCategory.Text.Length >= 3)) {
            // REF: Check if it already exists REF: http://stackoverflow.com/questions/22443634/how-to-check-if-a-value-already-exists-in-my-database-and-show-a-validation-mess
            // Set connection
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["RecipeLocalDatabaseR2ConnectionString"].ConnectionString);
            // Set query and insert commands
            SqlCommand searchCommand = new SqlCommand("SELECT * FROM dbo.comp229category WHERE categoryName= @CategoryName", connection);
            searchCommand.Parameters.AddWithValue("@CategoryName", this.txtCreateCategory.Text);
            SqlCommand insertCommand = new SqlCommand("INSERT INTO dbo.comp229category (categoryName) VALUES (@CategoryName)", connection);
            insertCommand.Parameters.AddWithValue("@CategoryName", txtCreateCategory.Text);

            try
            {
                // Open connection and execute with reader
                connection.Open();
                SqlDataReader categoryDateReader = searchCommand.ExecuteReader();
                bool flagCategoryDoesNotExist = true;
                // Read in the rows to check it
                while (categoryDateReader.Read())
                {
                    if (categoryDateReader.HasRows)
                    {
                        // It exists in the table already, set the flag
                        flagCategoryDoesNotExist = false;
                        break;
                    }
                }
                // Close the reader
                categoryDateReader.Close();
                if (flagCategoryDoesNotExist) // It does not exist, so insert it.
                {
                    insertCommand.ExecuteNonQuery();
                    lblCategoryResult.Text = "Category " + txtCreateCategory.Text + " created.";
                }
                else
                    lblCategoryResult.Text = "Category " + txtCreateCategory.Text + " already exists.";
                // Clear the text box and close the connection
            }
            catch (Exception ex)
            {
                lblCategoryResult.Text = ex.Message;
            }
            finally
            {
                txtCreateCategory.Text = "";
                connection.Close();
            }
        }
        else
            lblCategoryResult.Text = "Category name must be between 3 and 25 characters.";
    }
    protected void btnCreateCuisine_Click(object sender, EventArgs e)
    {
        if ((txtCreateCuisine.Text.Length <= 25) || (txtCreateCuisine.Text.Length >= 3))
        {
            // REF: Check if it already exists REF: http://stackoverflow.com/questions/22443634/how-to-check-if-a-value-already-exists-in-my-database-and-show-a-validation-mess
            // Set connection
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["RecipeLocalDatabaseR2ConnectionString"].ConnectionString);
            // Set query and insert commands
            SqlCommand searchCommand = new SqlCommand("SELECT * FROM dbo.comp229cuisine WHERE cuisineName= @CuisineName", connection);
            searchCommand.Parameters.AddWithValue("@CuisineName", txtCreateCuisine.Text);
            SqlCommand insertCommand = new SqlCommand("INSERT INTO dbo.comp229cuisine (cuisineName) VALUES (@CuisineName)", connection);
            insertCommand.Parameters.AddWithValue("@CuisineName", txtCreateCuisine.Text);

            try
            {
                // Open connection and execute with reader
                connection.Open();
                SqlDataReader cuisineDateReader = searchCommand.ExecuteReader();
                bool flagCuisineDoesNotExist = true;
                // Read in the rows to check it
                while (cuisineDateReader.Read())
                {
                    if (cuisineDateReader.HasRows)
                    {
                        // It exists in the table already, set the flag
                        flagCuisineDoesNotExist = false;
                        break;
                    }
                }
                // Close the reader
                cuisineDateReader.Close();
                if (flagCuisineDoesNotExist) // It does not exist, so insert it.
                {
                    insertCommand.ExecuteNonQuery();
                    lblCuisineResult.Text = "Cuisine " + txtCreateCuisine.Text + " created.";
                }
                else
                    lblCuisineResult.Text = "Cuisine " + txtCreateCuisine.Text + " already exists.";
                // Clear the text box and close the connection
            }
            catch (Exception ex)
            {
                lblCuisineResult.Text = ex.Message;
            }
            finally
            {
                txtCreateCuisine.Text = "";
                connection.Close();
            }
        }
        else
            lblCuisineResult.Text = "Cuisine name must be between 3 and 25 characters.";
    }
}